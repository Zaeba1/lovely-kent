package com.lovelykent.ui

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.lovelykent.R
import com.lovelykent.databinding.ActivityMainBinding
import com.lovelykent.effects.AtmosphereController
import com.lovelykent.effects.HorrorDirector
import com.lovelykent.scenario.CatMood
import com.lovelykent.scenario.Choice
import com.lovelykent.scenario.Scenario
import com.lovelykent.scenario.Scene
import com.lovelykent.scenario.SceneId
import com.lovelykent.scenario.Target
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** Показывает сцены сценария, связывает кнопки, эффекты и жизненный цикл. */
class StoryController(
    private val activity: Activity,
    private val b: ActivityMainBinding,
    private val finish: () -> Unit,
) {
    private val handler = Handler(Looper.getMainLooper())
    private val atmosphere = AtmosphereController(activity, b)
    private var current = Scenario.start
    private var choices: List<Choice> = emptyList()
    private var catAnim: ObjectAnimator? = null

    private val noLabels = intArrayOf(R.string.btn_no_0, R.string.btn_no_2, R.string.btn_no_3, R.string.btn_no_4)

    private val runaway = RunawayButtonController(b.stage, b.btnSecondary, ::obstacles, ::onFleeAttempt)

    private val horror = HorrorDirector(
        handler,
        listOf(
            HorrorDirector.Step(R.string.horror_1, 0.82f, 400L, 2600L),
            HorrorDirector.Step(R.string.horror_2, 0.88f, 700L, 2600L),
            HorrorDirector.Step(R.string.horror_3, 0.94f, 500L, 2800L),
            HorrorDirector.Step(R.string.horror_4, 1f, 900L, 2400L),
        ),
        onStep = ::onHorrorStep,
        onDone = { show(SceneId.FINALE) },
    )

    private val periodicGlitch = object : Runnable {
        override fun run() {
            b.glitch.burst(320L, 0.8f, b.title, b.catImage)
            handler.postDelayed(this, 3200L)
        }
    }

    init {
        b.btnPrimary.setOnClickListener { choices.getOrNull(0)?.let { handle(it.target) } }
        b.btnSecondary.setOnClickListener { choices.getOrNull(1)?.let { handle(it.target) } }
        b.btnExit.setOnClickListener { finish() }
        render(Scenario.scene(current))
    }

    // ---- навигация -------------------------------------------------------------------------

    private fun handle(target: Target) {
        when (target) {
            is Target.Go -> show(target.id)
            Target.Exit -> finish()
        }
    }

    private fun show(id: SceneId) {
        stopTimers()
        current = id
        val scene = Scenario.scene(id)
        b.column.animate().cancel()
        b.column.animate().alpha(0f).setDuration(160L).withEndAction {
            render(scene)
            b.column.animate().alpha(1f).setDuration(320L).start()
        }.start()
    }

    /** @return true, если Back обработан внутри истории; false — пусть Activity закроется. */
    fun goBack(): Boolean {
        if (current == SceneId.ASK) return false
        show(SceneId.ASK)
        return true
    }

    fun onGlobalTouch(x: Float, y: Float) {
        if (current == SceneId.ASK) runaway.onGlobalTouch(x, y)
    }

    // ---- жизненный цикл --------------------------------------------------------------------

    fun onStart() {
        if (current == SceneId.HORROR) horror.start()
        if (current == SceneId.FINALE) handler.postDelayed(periodicGlitch, 1500L)
    }

    fun onStop() {
        stopTimers()
    }

    fun release() {
        stopTimers()
        handler.removeCallbacksAndMessages(null)
        b.column.animate().cancel()
        atmosphere.release()
    }

    private fun stopTimers() {
        horror.cancel()
        handler.removeCallbacks(periodicGlitch)
        b.glitch.stop()
        catAnim?.cancel()
        catAnim = null
    }

    // ---- отрисовка сцены -------------------------------------------------------------------

    private fun render(scene: Scene) {
        runaway.enabled = scene.id == SceneId.ASK
        runaway.reset()
        choices = scene.choices

        b.catImage.animate().cancel()
        b.catImage.scaleX = 1f
        b.catImage.scaleY = 1f
        b.catImage.rotation = 0f
        b.catImage.setImageResource(scene.cat.drawable)

        b.title.setText(scene.title)
        if (scene.subtitle != null) {
            b.subtitle.setText(scene.subtitle)
            b.subtitle.visibility = View.VISIBLE
        } else {
            b.subtitle.text = ""
            b.subtitle.visibility = View.INVISIBLE
        }
        b.playground.visibility = if (scene.id == SceneId.ASK) View.VISIBLE else View.GONE

        if (scene.choices.isEmpty()) {
            b.buttonsRow.visibility = View.INVISIBLE
        } else {
            b.buttonsRow.visibility = View.VISIBLE
            b.btnPrimary.setText(scene.choices[0].label)
            b.btnSecondary.setText(scene.choices[1].label)
        }

        val morph = scene.cat == CatMood.HAPPY || scene.cat == CatMood.SAD
        atmosphere.setIntensity(scene.intensity, morph)

        if (scene.heartsBurst) {
            b.hearts.post { b.hearts.burst(34) }
            handler.postDelayed({ b.hearts.burst(22) }, 700L)
            pulseCat(1.08f, 4)
        }
        if (scene.glitchOnEnter) {
            b.stage.post { b.glitch.burst(450L, 0.9f, b.title, b.catImage) }
        }
        when (scene.id) {
            SceneId.HORROR -> horror.start()
            SceneId.FINALE -> handler.postDelayed(periodicGlitch, 3000L)
            else -> Unit
        }
    }

    private fun pulseCat(scale: Float, repeats: Int) {
        catAnim?.cancel()
        catAnim = ObjectAnimator.ofPropertyValuesHolder(
            b.catImage,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, scale, 1f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, scale, 1f),
        ).apply {
            duration = 700L
            repeatCount = repeats
            start()
        }
    }

    // ---- реакции на попытки нажать «Нет» ---------------------------------------------------

    private fun onFleeAttempt(n: Int) {
        val labelIdx = when {
            n <= 0 -> 0
            n <= 2 -> 1
            n <= 4 -> 2
            else -> 3
        }
        b.btnSecondary.setText(noLabels[labelIdx])

        val reaction = when (n) {
            1 -> R.string.react_1
            3 -> R.string.react_2
            4 -> R.string.react_3
            6 -> R.string.react_4
            8 -> R.string.react_5
            9 -> R.string.react_6
            else -> null
        }
        if (reaction != null) {
            b.subtitle.setText(reaction)
            b.subtitle.visibility = View.VISIBLE
        }

        if (n >= 3) {
            catAnim?.cancel()
            catAnim = ObjectAnimator.ofFloat(b.catImage, View.ROTATION, 0f, -6f, 6f, -3f, 3f, 0f).apply {
                duration = 420L
                start()
            }
        }
        if (n == 6) b.glitch.burst(220L, 0.3f, b.catImage)
        if (n == 8) b.glitch.burst(380L, 0.55f, b.catImage, b.title)

        atmosphere.setIntensity(min(n * 0.03f, 0.27f), true, 300L)
    }

    private fun onHorrorStep(step: HorrorDirector.Step) {
        b.title.setText(step.line)
        atmosphere.setIntensity(step.intensity, false, 500L)
        b.glitch.burst(step.glitchMs, 0.6f + (step.intensity - 0.8f), b.title, b.catImage)
        val s = 1f + (step.intensity - 0.8f) * 0.8f
        b.catImage.animate().scaleX(s).scaleY(s).setDuration(step.holdMs).start()
    }

    // ---- препятствия для убегающей кнопки --------------------------------------------------

    private fun obstacles(): List<Rect> {
        val list = ArrayList<Rect>(5)
        list.add(drawnImageRect(b.catImage))
        textRect(b.title)?.let { list.add(it) }
        list.add(RunawayButtonController.screenRect(b.subtitle)) // зарезервировано под реакции
        list.add(RunawayButtonController.screenRect(b.btnPrimary))
        list.add(RunawayButtonController.screenRect(b.btnExit))
        return list
    }

    private fun textRect(tv: TextView): Rect? {
        val layout = tv.layout ?: return RunawayButtonController.screenRect(tv)
        var maxW = 0f
        for (i in 0 until layout.lineCount) maxW = max(maxW, layout.getLineWidth(i))
        val loc = IntArray(2)
        tv.getLocationOnScreen(loc)
        val avail = tv.width - tv.paddingLeft - tv.paddingRight
        val left = loc[0] + tv.paddingLeft + ((avail - maxW) / 2f).toInt()
        return Rect(left, loc[1], left + ceil(maxW).toInt(), loc[1] + tv.height)
    }

    private fun drawnImageRect(iv: ImageView): Rect {
        val full = RunawayButtonController.screenRect(iv)
        val d = iv.drawable ?: return full
        val vw = iv.width - iv.paddingLeft - iv.paddingRight
        val vh = iv.height - iv.paddingTop - iv.paddingBottom
        val dw = d.intrinsicWidth
        val dh = d.intrinsicHeight
        if (dw <= 0 || dh <= 0 || vw <= 0 || vh <= 0) return full
        val scale = min(vw.toFloat() / dw, vh.toFloat() / dh)
        val w = (dw * scale).toInt()
        val h = (dh * scale).toInt()
        val left = full.left + iv.paddingLeft + (vw - w) / 2
        val top = full.top + iv.paddingTop + (vh - h) / 2
        return Rect(left, top, left + w, top + h)
    }
}
