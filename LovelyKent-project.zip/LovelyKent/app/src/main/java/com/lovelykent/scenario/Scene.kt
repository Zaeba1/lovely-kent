package com.lovelykent.scenario

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.lovelykent.R

enum class SceneId { ASK, YES, SURE, HURT, COLD, WATCH, HORROR, FINALE }

enum class CatMood(@DrawableRes val drawable: Int) {
    HAPPY(R.drawable.cat_happy),
    SAD(R.drawable.cat_sad),
    LOVE(R.drawable.cat_love),
    SCARY(R.drawable.cat_scary),
    FINAL(R.drawable.cat_horror_final),
}

sealed interface Target {
    data class Go(val id: SceneId) : Target
    data object Exit : Target
}

data class Choice(@StringRes val label: Int, val target: Target)

data class Scene(
    val id: SceneId,
    @StringRes val title: Int,
    @StringRes val subtitle: Int?,
    val cat: CatMood,
    /** 0f = полностью романтично, 1f = полный хоррор. */
    val intensity: Float,
    val choices: List<Choice>,
    val glitchOnEnter: Boolean = false,
    val heartsBurst: Boolean = false,
)
