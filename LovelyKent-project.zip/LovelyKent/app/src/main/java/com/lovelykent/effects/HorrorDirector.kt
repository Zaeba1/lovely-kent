package com.lovelykent.effects

import android.os.Handler
import androidx.annotation.StringRes

/** Последовательность кадров хоррор-сцены с таймингом. Полностью отменяемая. */
class HorrorDirector(
    private val handler: Handler,
    private val steps: List<Step>,
    private val onStep: (Step) -> Unit,
    private val onDone: () -> Unit,
) {
    data class Step(
        @StringRes val line: Int,
        val intensity: Float,
        val glitchMs: Long,
        val holdMs: Long,
    )

    private var index = 0

    private val runner = object : Runnable {
        override fun run() {
            if (index >= steps.size) {
                onDone()
                return
            }
            val step = steps[index++]
            onStep(step)
            handler.postDelayed(this, step.holdMs)
        }
    }

    fun start() {
        cancel()
        index = 0
        handler.post(runner)
    }

    fun cancel() {
        handler.removeCallbacks(runner)
    }
}
