package com.lovelykent.effects

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

/**
 * Прозрачный слой с короткими глитчами: цветные полосы + дрожание переданных view.
 * Не перехватывает касания и полностью живёт внутри приложения.
 */
class GlitchOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    private class Bar(val y: Float, val h: Float, val x: Float, val w: Float, val color: Int)

    private val paint = Paint()
    private val density = resources.displayMetrics.density
    private var bars: List<Bar> = emptyList()
    private var strength = 1f
    private var untilMs = 0L
    private var targets: List<View> = emptyList()

    private val tick = object : Runnable {
        override fun run() {
            if (SystemClock.uptimeMillis() < untilMs && isAttachedToWindow) {
                regenerate()
                jitterTargets()
                invalidate()
                postDelayed(this, 55L)
            } else {
                stop()
            }
        }
    }

    init {
        isClickable = false
        isFocusable = false
    }

    fun burst(durationMs: Long, strength: Float = 1f, vararg views: View) {
        if (width == 0 || height == 0) return
        resetTargets()
        this.strength = strength.coerceIn(0.1f, 1.5f)
        untilMs = SystemClock.uptimeMillis() + durationMs
        targets = views.toList()
        removeCallbacks(tick)
        post(tick)
    }

    fun stop() {
        removeCallbacks(tick)
        bars = emptyList()
        resetTargets()
        invalidate()
    }

    private fun regenerate() {
        val count = (3 + Random.nextInt(5) * strength).toInt()
        bars = List(count) {
            val red = Random.nextBoolean()
            Bar(
                y = Random.nextFloat() * height,
                h = density * (2f + Random.nextFloat() * 22f),
                x = Random.nextFloat() * width * 0.4f,
                w = width * (0.3f + Random.nextFloat() * 0.7f),
                color = if (red) Color.argb((50 + 70 * strength).toInt().coerceAtMost(200), 255, 30, 40)
                else Color.argb((40 + 50 * strength).toInt().coerceAtMost(160), 0, 255, 255),
            )
        }
    }

    private fun jitterTargets() {
        for (v in targets) {
            v.translationX = (Random.nextFloat() - 0.5f) * density * 18f * strength
            v.scaleX = 1f + (Random.nextFloat() - 0.5f) * 0.08f * strength
            v.alpha = if (Random.nextInt(5) == 0) 0.55f else 1f
        }
    }

    private fun resetTargets() {
        for (v in targets) {
            v.translationX = 0f
            v.scaleX = 1f
            v.alpha = 1f
        }
        targets = emptyList()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (b in bars) {
            paint.color = b.color
            canvas.drawRect(b.x, b.y, b.x + b.w, b.y + b.h, paint)
        }
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }
}
